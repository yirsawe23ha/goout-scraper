import csv
import asyncio
from playwright.async_api import async_playwright

OUTPUT_FILE = "events.csv"

async def run():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        await page.goto("https://www.go-out.co/s/parties")
        await page.wait_for_timeout(3000)

        for _ in range(5):
            await page.mouse.wheel(0, 3000)
            await page.wait_for_timeout(1500)

        links = await page.eval_on_selector_all(
            'a[href*="/event/"]',
            "els => els.map(e => e.href)"
        )
        unique_links = list(set([link for link in links if "event" in link]))

        print(f"✅ נמצאו {len(unique_links)} לינקים")

        events = []

        for i, link in enumerate(unique_links):
            print(f"🔍 ({i+1}/{len(unique_links)}) נכנס ל: {link}")
            await page.goto(link)
            await page.wait_for_timeout(2000)

            try:
                title = await page.text_content("h1")
                date = await page.text_content(".event-header-date")
                location = await page.text_content(".event-header-location")
                description = await page.text_content(".event-about")
                image = await page.get_attribute("img", "src")

                if "ישראל" not in location and "תל אביב" not in location:
                    continue

                city = "תל אביב" if "תל אביב" in location else location.split(",")[0]

                events.append({
                    "title": title.strip() if title else "",
                    "date": date.strip() if date else "",
                    "location": location.strip() if location else "",
                    "city": city,
                    "country": "ישראל",
                    "image": image,
                    "description": description.strip() if description else "",
                    "url": link
                })
            except Exception as e:
                print(f"❌ שגיאה בלינק {link}: {e}")
                continue

        await browser.close()

        keys = ["title", "date", "location", "city", "country", "image", "description", "url"]
        with open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(events)

        print(f"🎉 {len(events)} אירועים נשמרו לקובץ {OUTPUT_FILE}")

asyncio.run(run())
